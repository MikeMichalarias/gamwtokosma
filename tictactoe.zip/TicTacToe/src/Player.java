
public class Player {
	
	private String name;
	private float wins;
	private float draws;
	private float loses;
	private float numOfGames;
	
	private float score=50*(2*wins+draws)/numOfGames;
	
	//5 best games
	
	
	
	
	
}

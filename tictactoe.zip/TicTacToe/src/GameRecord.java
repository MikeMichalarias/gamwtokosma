
public class GameRecord {

}

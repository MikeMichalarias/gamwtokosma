
public class PlayerRoster {

	
	
	
	public void findPlayerNames() {
		
	}
	public void findPlayer(String name) {
		
	}
	public void findHallOfFame(int n) {
		
	}
}
